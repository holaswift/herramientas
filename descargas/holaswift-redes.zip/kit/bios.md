# hola Swift · perfiles en redes

Nombre visible en todas: **hola Swift**

## X (104/160 caracteres)

```
La comunidad de Swift en español. Charlas online cada mes y un encuentro en persona. Ya no estáis solos.
```

## Instagram (104/150 caracteres)

```
La comunidad de Swift en español.
Charlas online cada mes y un encuentro en persona.
Ya no estáis solos.
```

## Threads (104/150 caracteres)

```
La comunidad de Swift en español. Charlas online cada mes y un encuentro en persona. Ya no estáis solos.
```

## Bluesky (150/256 caracteres)

```
La comunidad de Swift en español: charlas online cada mes y un encuentro en persona. Para quien programa en Swift y lo hacía solo. Ya no estáis solos.
```

## Mastodon (300/500 caracteres)

```
La comunidad de Swift en español.

Una charla online cada mes y un encuentro en persona, para quien programa en Swift, SwiftUI y el resto del ecosistema de Apple desde España y Latinoamérica.

Contamos lo bueno, lo malo y lo que está por venir. Ya no estáis solos.

#Swift #SwiftUI #iOSDev #holaswift
```

## LinkedIn · eslogan (84/120 caracteres)

```
La comunidad de Swift en español: charlas online cada mes y un encuentro en persona.
```

## LinkedIn · acerca de (657/2000 caracteres)

```
hola Swift es la comunidad de Swift en español.

Durante mucho tiempo, quien programa en Swift en español ha aprendido solo: documentación en inglés, vídeos en inglés y pocas caras conocidas. hola Swift existe para cambiar eso.

Qué hacemos:
· Una charla online cada mes, desde enero de 2027, en directo y en español.
· Un encuentro en persona, para vernos las caras.

Para quién: desarrolladoras y desarrolladores de iOS, macOS y el resto de plataformas de Apple, de España y Latinoamérica, empiecen ahora o lleven años.

Cómo hablamos: de lo bueno, de lo malo y de lo que está por venir.

Ya no estáis solos.

Organizan Jon y Ale. Diseño de Chubby Studio.
```
