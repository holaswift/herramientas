# hola Swift · kit de perfiles para redes

Todo lo necesario para dejar los perfiles iguales en todas las redes. Las bios, listas para copiar, están en `bios.md`.

## Qué subir en cada red

| Red | Foto de perfil | Cabecera | Dónde se cambia |
|---|---|---|---|
| **X** (@hola_swift) | `x/perfil-logo-claro.png` | `x/cabecera-x-claro.jpg` (1500×500) | Perfil › Editar perfil |
| **Mastodon** (@hola_swift@mastodon.social) | `mastodon/perfil-logo-claro.png` | `mastodon/cabecera-mastodon-claro.jpg` (1500×500) | Preferencias › Perfil público |
| **Bluesky** (@hola-swift.bsky.social) | `bluesky/perfil-logo-claro.png` | `bluesky/cabecera-bluesky-claro.jpg` (3000×1000) | Perfil › Editar perfil |
| **LinkedIn** (página de empresa) | `linkedin/perfil-logo-claro.png` | `linkedin/portada-linkedin-claro.jpg` (2256×382, el doble del tamaño de LinkedIn para que se vea nítida) | Herramientas de administrador › Editar página |
| **Instagram** (@hola_swift) | `instagram-threads/perfil-logo-claro.png` | No tiene cabecera. Portadas de destacados: `instagram-threads/destacado-*.png` | Editar perfil |
| **Threads** (@hola_swift) | La misma de Instagram (Threads la importa) | No tiene cabecera | Editar perfil |

Todas las fotos de perfil son de 1080×1080: cada red las recorta en círculo y las reduce sola.

## Variantes

- **Cabeceras:** cada una en `claro` (papel, la recomendada), `oscuro` y `color` (rosa de comunidad, con el hola y el texto en blanco). Usad la misma variante en todas las redes.
- **Foto de perfil:**
  - `perfil-logo-*`: el logotipo apilado. Es la que pide el libro de marca para perfiles.
  - `perfil-h-*`: la "h" sola, que se lee mejor en tamaños muy pequeños (por ejemplo en las respuestas de X). Elegid una y usadla en todas.
- **Destacados de Instagram:**
  - charlas: llaves sobre azul
  - encuentro: corazón sobre naranja
  - comunidad: @ sobre rosa
  - personas: mano sobre verde
  - patrocinio: código sobre violeta

  Instagram los recorta en círculo desde el centro.

## Campos que conviene rellenar

- **Nombre visible:** hola Swift. Dos palabras, "hola" en minúscula. El usuario de cada red lleva guion bajo (@hola_swift), pero el nombre visible lleva espacio.
- **Enlace:** https://holaswift.com
- **Mastodon:** en "Metadatos del perfil" se pueden añadir la web, el Discord y las otras redes. Si en la web se pone un enlace `rel="me"` al perfil de Mastodon, el enlace sale verificado.
- **LinkedIn:** sector "Software", tamaño "1-10" (o el que corresponda) y el texto "acerca de" de `bios.md`.
