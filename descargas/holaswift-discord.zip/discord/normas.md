# :wave: ¡Hola, comunidad!

**hola Swift** es una comunidad en español para personas interesadas en Swift, SwiftUI y el desarrollo de apps para las plataformas de Apple. Un espacio para aprender, compartir, resolver dudas, enseñar tus proyectos y conocer a gente con la misma pasión.

Te pedimos que respetes estas normas. Valen aquí, en las sesiones online y en los encuentros en persona.

### 01. :handshake: Respeta a las demás personas
Trata a todo el mundo con respeto y amabilidad. No toleramos insultos, discriminación, acoso ni comportamientos ofensivos.

### 02. :seedling: Siempre estamos aprendiendo
Empieces hoy o lleves años con Swift, todas las preguntas son bienvenidas. Comparte lo que sabes con paciencia y sin juzgar.

### 03. :speech_balloon: Cada conversación en su sitio
Usa el canal de cada tema: así todo es más fácil de encontrar.

### 04. :no_entry_sign: Nada de spam ni publicidad
No publiques contenido repetitivo ni publicidad que nadie ha pedido. Tus proyectos, apps y recursos son bienvenidos en los canales pensados para ello.

### 05. :lock: Respeta la privacidad
No compartas datos personales, conversaciones privadas ni contenido de otras personas sin su permiso.

### 06. :microphone2: Participa con respeto
En los canales de voz, las sesiones y los encuentros, respeta los turnos de palabra y las indicaciones de quienes organizan.

### 07. :shield: Ayúdanos a cuidar la comunidad
Sigue las indicaciones del equipo de moderación. Si ves algo que no está bien, avísanos por privado o escríbenos a comunidad@holaswift.com. Tratamos cada aviso con discreción.

## :blue_heart: Lo más importante

**hola Swift es una comunidad que hacemos entre todos.**
Pregunta, comparte, ayuda, experimenta y disfruta aprendiendo. No hace falta saberlo todo para formar parte de ella: basta con tener ganas de aprender y de compartir.

:page_facing_up: Código de conducta completo: https://holaswift.com/codigo-de-conducta

**¡Nos vemos en los canales! :rocket:**
